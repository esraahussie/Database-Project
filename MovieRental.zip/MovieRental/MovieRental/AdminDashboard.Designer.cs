﻿namespace MovieRental
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnManageUsers = new System.Windows.Forms.Button();
            this.bottun2 = new System.Windows.Forms.Button();
            this.botton4 = new System.Windows.Forms.Button();
            this.btnManageGenere = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admin dashboard";
            // 
            // btnManageUsers
            // 
            this.btnManageUsers.Location = new System.Drawing.Point(51, 91);
            this.btnManageUsers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnManageUsers.Name = "btnManageUsers";
            this.btnManageUsers.Size = new System.Drawing.Size(180, 53);
            this.btnManageUsers.TabIndex = 1;
            this.btnManageUsers.Text = "Manage Users";
            this.btnManageUsers.UseVisualStyleBackColor = true;
            this.btnManageUsers.Click += new System.EventHandler(this.btnManageUsers_Click);
            // 
            // bottun2
            // 
            this.bottun2.Location = new System.Drawing.Point(273, 91);
            this.bottun2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bottun2.Name = "bottun2";
            this.bottun2.Size = new System.Drawing.Size(190, 53);
            this.bottun2.TabIndex = 2;
            this.bottun2.Text = "Manage Movies";
            this.bottun2.UseVisualStyleBackColor = true;
            this.bottun2.Click += new System.EventHandler(this.button2_Click);
            // 
            // botton4
            // 
            this.botton4.Location = new System.Drawing.Point(283, 242);
            this.botton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.botton4.Name = "botton4";
            this.botton4.Size = new System.Drawing.Size(176, 53);
            this.botton4.TabIndex = 4;
            this.botton4.Text = "Review User Feedback";
            this.botton4.UseVisualStyleBackColor = true;
            this.botton4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnManageGenere
            // 
            this.btnManageGenere.Location = new System.Drawing.Point(493, 91);
            this.btnManageGenere.Name = "btnManageGenere";
            this.btnManageGenere.Size = new System.Drawing.Size(159, 53);
            this.btnManageGenere.TabIndex = 5;
            this.btnManageGenere.Text = "Manage genere";
            this.btnManageGenere.UseVisualStyleBackColor = true;
            this.btnManageGenere.Click += new System.EventHandler(this.btnManageGenere_Click);
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnManageGenere);
            this.Controls.Add(this.botton4);
            this.Controls.Add(this.bottun2);
            this.Controls.Add(this.btnManageUsers);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AdminDashboard";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnManageUsers;
        private System.Windows.Forms.Button bottun2;
        private System.Windows.Forms.Button botton4;
        private System.Windows.Forms.Button btnManageGenere;
    }
}

