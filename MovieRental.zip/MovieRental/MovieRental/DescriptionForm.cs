﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class DescriptionForm : Form
    {
        private string selectedMovie;

        public DescriptionForm(string movieName)
        {
            InitializeComponent();
            selectedMovie = movieName;
        }

        private void DescriptionForm_Load(object sender, EventArgs e)
        {
            LoadMovieDetails();
        }

        private void LoadMovieDetails()
        {
            string connectionString = "Data Source=DESKTOP-VF0BM3L\\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";
            string query = "SELECT MOVIE_NAME, MOVIE_YEAR, ACTOR_NAME, SUPPLIER_NAME, AVAILABILITY FROM Movies WHERE MOVIE_NAME = @movieName";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@movieName", selectedMovie);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        label6.Text = reader["MOVIE_NAME"].ToString();
                        label7.Text = reader["MOVIE_YEAR"].ToString();
                        label8.Text = reader["ACTOR_NAME"].ToString();
                        label9.Text = reader["SUPPLIER_NAME"].ToString();

                        string availability = reader["AVAILABILITY"].ToString();
                        label10.Text = availability;

                        // تأكد من حالة التوفر وفعّل أو عطّل زر Rent
                        if (availability.ToLower() == "available")
                        {
                            button1.Enabled = true;
                        }
                        else
                        {
                            button1.Enabled = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Movie details not found.");
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading movie details: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // زر Rent - لو الفيلم متوفر، يفتح PaymentForm، لو لا يعرض رسالة
            if (label10.Text.ToLower() == "available")
            {
                PaymentForm paymentForm = new PaymentForm(selectedMovie);
                paymentForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("This movie is not available to rent.");
            }
        }
    }
}