﻿namespace MovieRental
{
    partial class DisplayMovies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.msdbDataSet2 = new MovieRental.msdbDataSet2();
            this.mOVIEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mOVIETableAdapter = new MovieRental.msdbDataSet2TableAdapters.MOVIETableAdapter();
            this.mOVIEIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gENEREIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDMINIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sUPPLIERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mOVIENAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mOVIEYEARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aVAILABILITYDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pRICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addeddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mOVIEIDDataGridViewTextBoxColumn,
            this.gENEREIDDataGridViewTextBoxColumn,
            this.aDMINIDDataGridViewTextBoxColumn,
            this.sUPPLIERIDDataGridViewTextBoxColumn,
            this.mOVIENAMEDataGridViewTextBoxColumn,
            this.mOVIEYEARDataGridViewTextBoxColumn,
            this.aVAILABILITYDataGridViewCheckBoxColumn,
            this.pRICEDataGridViewTextBoxColumn,
            this.addeddateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.mOVIEBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(48, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(740, 251);
            this.dataGridView1.TabIndex = 0;
            // 
            // msdbDataSet2
            // 
            this.msdbDataSet2.DataSetName = "msdbDataSet2";
            this.msdbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mOVIEBindingSource
            // 
            this.mOVIEBindingSource.DataMember = "MOVIE";
            this.mOVIEBindingSource.DataSource = this.msdbDataSet2;
            // 
            // mOVIETableAdapter
            // 
            this.mOVIETableAdapter.ClearBeforeFill = true;
            // 
            // mOVIEIDDataGridViewTextBoxColumn
            // 
            this.mOVIEIDDataGridViewTextBoxColumn.DataPropertyName = "MOVIE_ID";
            this.mOVIEIDDataGridViewTextBoxColumn.HeaderText = "MOVIE_ID";
            this.mOVIEIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mOVIEIDDataGridViewTextBoxColumn.Name = "mOVIEIDDataGridViewTextBoxColumn";
            this.mOVIEIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // gENEREIDDataGridViewTextBoxColumn
            // 
            this.gENEREIDDataGridViewTextBoxColumn.DataPropertyName = "GENERE_ID";
            this.gENEREIDDataGridViewTextBoxColumn.HeaderText = "GENERE_ID";
            this.gENEREIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gENEREIDDataGridViewTextBoxColumn.Name = "gENEREIDDataGridViewTextBoxColumn";
            this.gENEREIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aDMINIDDataGridViewTextBoxColumn
            // 
            this.aDMINIDDataGridViewTextBoxColumn.DataPropertyName = "ADMIN_ID";
            this.aDMINIDDataGridViewTextBoxColumn.HeaderText = "ADMIN_ID";
            this.aDMINIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aDMINIDDataGridViewTextBoxColumn.Name = "aDMINIDDataGridViewTextBoxColumn";
            this.aDMINIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // sUPPLIERIDDataGridViewTextBoxColumn
            // 
            this.sUPPLIERIDDataGridViewTextBoxColumn.DataPropertyName = "SUPPLIER_ID";
            this.sUPPLIERIDDataGridViewTextBoxColumn.HeaderText = "SUPPLIER_ID";
            this.sUPPLIERIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sUPPLIERIDDataGridViewTextBoxColumn.Name = "sUPPLIERIDDataGridViewTextBoxColumn";
            this.sUPPLIERIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // mOVIENAMEDataGridViewTextBoxColumn
            // 
            this.mOVIENAMEDataGridViewTextBoxColumn.DataPropertyName = "MOVIE_NAME";
            this.mOVIENAMEDataGridViewTextBoxColumn.HeaderText = "MOVIE_NAME";
            this.mOVIENAMEDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mOVIENAMEDataGridViewTextBoxColumn.Name = "mOVIENAMEDataGridViewTextBoxColumn";
            this.mOVIENAMEDataGridViewTextBoxColumn.Width = 125;
            // 
            // mOVIEYEARDataGridViewTextBoxColumn
            // 
            this.mOVIEYEARDataGridViewTextBoxColumn.DataPropertyName = "MOVIE_YEAR";
            this.mOVIEYEARDataGridViewTextBoxColumn.HeaderText = "MOVIE_YEAR";
            this.mOVIEYEARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mOVIEYEARDataGridViewTextBoxColumn.Name = "mOVIEYEARDataGridViewTextBoxColumn";
            this.mOVIEYEARDataGridViewTextBoxColumn.Width = 125;
            // 
            // aVAILABILITYDataGridViewCheckBoxColumn
            // 
            this.aVAILABILITYDataGridViewCheckBoxColumn.DataPropertyName = "AVAILABILITY";
            this.aVAILABILITYDataGridViewCheckBoxColumn.HeaderText = "AVAILABILITY";
            this.aVAILABILITYDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.aVAILABILITYDataGridViewCheckBoxColumn.Name = "aVAILABILITYDataGridViewCheckBoxColumn";
            this.aVAILABILITYDataGridViewCheckBoxColumn.Width = 125;
            // 
            // pRICEDataGridViewTextBoxColumn
            // 
            this.pRICEDataGridViewTextBoxColumn.DataPropertyName = "PRICE";
            this.pRICEDataGridViewTextBoxColumn.HeaderText = "PRICE";
            this.pRICEDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pRICEDataGridViewTextBoxColumn.Name = "pRICEDataGridViewTextBoxColumn";
            this.pRICEDataGridViewTextBoxColumn.Width = 125;
            // 
            // addeddateDataGridViewTextBoxColumn
            // 
            this.addeddateDataGridViewTextBoxColumn.DataPropertyName = "added_date";
            this.addeddateDataGridViewTextBoxColumn.HeaderText = "added_date";
            this.addeddateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addeddateDataGridViewTextBoxColumn.Name = "addeddateDataGridViewTextBoxColumn";
            this.addeddateDataGridViewTextBoxColumn.Width = 125;
            // 
            // DisplayMovies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Name = "DisplayMovies";
            this.Text = "DisplayMovies";
            this.Load += new System.EventHandler(this.DisplayMovies_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private msdbDataSet2 msdbDataSet2;
        private System.Windows.Forms.BindingSource mOVIEBindingSource;
        private msdbDataSet2TableAdapters.MOVIETableAdapter mOVIETableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn mOVIEIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gENEREIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDMINIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sUPPLIERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mOVIENAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mOVIEYEARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn aVAILABILITYDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pRICEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addeddateDataGridViewTextBoxColumn;
    }
}