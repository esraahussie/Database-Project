﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class DisplayMovies : Form
    {
        public DisplayMovies()
        {
            InitializeComponent();
        }

        private void DisplayMovies_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'msdbDataSet2.MOVIE' table. You can move, or remove it, as needed.
            this.mOVIETableAdapter.Fill(this.msdbDataSet2.MOVIE);

        }
    }
}
