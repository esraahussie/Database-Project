﻿using System;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class HomePageForm : Form
    {
        public HomePageForm()
        {
            InitializeComponent();
            btnSignUp.Click += BtnSignUp_Click;
            btnLogin.Click += BtnLogin_Click;
        }

        private void BtnSignUp_Click(object sender, EventArgs e)
        {
            InBetween inBetween = new InBetween();
            inBetween.Show();
            this.Hide();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void HomePageForm_Load(object sender, EventArgs e)
        {
        }
    }
}