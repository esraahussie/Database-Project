﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class InBetween : Form
    {
        public InBetween()
        {
            InitializeComponent();
        }

        private void InBetween_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminSignUp adminSignUp = new AdminSignUp();
            adminSignUp.Show();
            this.Hide(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserSignUp adminSignUp = new UserSignUp();
            adminSignUp.Show();
            this.Hide();
        }
    }
}
