﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();

            // اربط الزر بالحدث
            btnLogin.Click += (s, e) => CheckLogin();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
        }

        private void CheckLogin()
        {
            string id = textBox1.Text.Trim();
            string email = textBox2.Text.Trim();

            if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Please enter both ID and Email.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "Data Source=DESKTOP-VF0BM3L\\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // 1. Check in User table
                    string queryUser = "SELECT COUNT(*) FROM [User] WHERE USER_ID = @id AND EMAIL = @email";
                    SqlCommand cmdUser = new SqlCommand(queryUser, conn);
                    cmdUser.Parameters.AddWithValue("@id", id);
                    cmdUser.Parameters.AddWithValue("@email", email);

                    int userCount = (int)cmdUser.ExecuteScalar();

                    if (userCount > 0)
                    {
                        UserDashboard userDashboard = new UserDashboard();
                        userDashboard.Show();
                        this.Hide();
                        return;
                    }

                    // 2. Check in Admin table
                    string queryAdmin = "SELECT COUNT(*) FROM [Admin] WHERE ADMIN_ID = @id AND ADMIN_MAIL = @email";
                    SqlCommand cmdAdmin = new SqlCommand(queryAdmin, conn);
                    cmdAdmin.Parameters.AddWithValue("@id", id);
                    cmdAdmin.Parameters.AddWithValue("@email", email);

                    int adminCount = (int)cmdAdmin.ExecuteScalar();

                    if (adminCount > 0)
                    {
                        AdminDashboard adminDashboard = new AdminDashboard();
                        adminDashboard.Show();
                        this.Hide();
                        return;
                    }

                    // 3. If not found
                    MessageBox.Show("Invalid ID or Email.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to the database:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}