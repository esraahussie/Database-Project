﻿namespace MovieRental
{
    partial class ManageGenereForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.gENEREIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gENERENAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gENEREBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.msdbDataSet2 = new MovieRental.msdbDataSet2();
            this.gENERETableAdapter = new MovieRental.msdbDataSet2TableAdapters.GENERETableAdapter();
            this.btnAddGenere = new System.Windows.Forms.Button();
            this.btnUpdateGenere = new System.Windows.Forms.Button();
            this.btnDeleteGenere = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtGenererId = new System.Windows.Forms.TextBox();
            this.txtGenereName = new System.Windows.Forms.TextBox();
            this.btnShowGenereDate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gENEREBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gENEREIDDataGridViewTextBoxColumn,
            this.gENERENAMEDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.gENEREBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(389, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(344, 251);
            this.dataGridView1.TabIndex = 0;
            // 
            // gENEREIDDataGridViewTextBoxColumn
            // 
            this.gENEREIDDataGridViewTextBoxColumn.DataPropertyName = "GENERE_ID";
            this.gENEREIDDataGridViewTextBoxColumn.HeaderText = "GENERE_ID";
            this.gENEREIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gENEREIDDataGridViewTextBoxColumn.Name = "gENEREIDDataGridViewTextBoxColumn";
            this.gENEREIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // gENERENAMEDataGridViewTextBoxColumn
            // 
            this.gENERENAMEDataGridViewTextBoxColumn.DataPropertyName = "GENERE_NAME";
            this.gENERENAMEDataGridViewTextBoxColumn.HeaderText = "GENERE_NAME";
            this.gENERENAMEDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gENERENAMEDataGridViewTextBoxColumn.Name = "gENERENAMEDataGridViewTextBoxColumn";
            this.gENERENAMEDataGridViewTextBoxColumn.Width = 125;
            // 
            // gENEREBindingSource
            // 
            this.gENEREBindingSource.DataMember = "GENERE";
            this.gENEREBindingSource.DataSource = this.msdbDataSet2;
            // 
            // msdbDataSet2
            // 
            this.msdbDataSet2.DataSetName = "msdbDataSet2";
            this.msdbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gENERETableAdapter
            // 
            this.gENERETableAdapter.ClearBeforeFill = true;
            // 
            // btnAddGenere
            // 
            this.btnAddGenere.Location = new System.Drawing.Point(65, 265);
            this.btnAddGenere.Name = "btnAddGenere";
            this.btnAddGenere.Size = new System.Drawing.Size(75, 23);
            this.btnAddGenere.TabIndex = 1;
            this.btnAddGenere.Text = "Add ";
            this.btnAddGenere.UseVisualStyleBackColor = true;
            this.btnAddGenere.Click += new System.EventHandler(this.btnAddGenere_Click);
            // 
            // btnUpdateGenere
            // 
            this.btnUpdateGenere.Location = new System.Drawing.Point(178, 265);
            this.btnUpdateGenere.Name = "btnUpdateGenere";
            this.btnUpdateGenere.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateGenere.TabIndex = 2;
            this.btnUpdateGenere.Text = "Update";
            this.btnUpdateGenere.UseVisualStyleBackColor = true;
            this.btnUpdateGenere.Click += new System.EventHandler(this.btnUpdateGenere_Click);
            // 
            // btnDeleteGenere
            // 
            this.btnDeleteGenere.Location = new System.Drawing.Point(308, 265);
            this.btnDeleteGenere.Name = "btnDeleteGenere";
            this.btnDeleteGenere.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteGenere.TabIndex = 3;
            this.btnDeleteGenere.Text = "Delete";
            this.btnDeleteGenere.UseVisualStyleBackColor = true;
            this.btnDeleteGenere.Click += new System.EventHandler(this.btnDeleteGenere_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Genere ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Genere Name";
            // 
            // txtGenererId
            // 
            this.txtGenererId.Location = new System.Drawing.Point(210, 74);
            this.txtGenererId.Name = "txtGenererId";
            this.txtGenererId.Size = new System.Drawing.Size(100, 22);
            this.txtGenererId.TabIndex = 6;
            // 
            // txtGenereName
            // 
            this.txtGenereName.Location = new System.Drawing.Point(210, 121);
            this.txtGenereName.Name = "txtGenereName";
            this.txtGenereName.Size = new System.Drawing.Size(100, 22);
            this.txtGenereName.TabIndex = 7;
            // 
            // btnShowGenereDate
            // 
            this.btnShowGenereDate.Location = new System.Drawing.Point(210, 342);
            this.btnShowGenereDate.Name = "btnShowGenereDate";
            this.btnShowGenereDate.Size = new System.Drawing.Size(75, 23);
            this.btnShowGenereDate.TabIndex = 8;
            this.btnShowGenereDate.Text = "Show";
            this.btnShowGenereDate.UseVisualStyleBackColor = true;
            this.btnShowGenereDate.Click += new System.EventHandler(this.btnShowGenereDate_Click);
            // 
            // ManageGenereForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnShowGenereDate);
            this.Controls.Add(this.txtGenereName);
            this.Controls.Add(this.txtGenererId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDeleteGenere);
            this.Controls.Add(this.btnUpdateGenere);
            this.Controls.Add(this.btnAddGenere);
            this.Controls.Add(this.dataGridView1);
            this.Name = "ManageGenereForm";
            this.Text = "ManageGenere";
            this.Load += new System.EventHandler(this.ManageGenere_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gENEREBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private msdbDataSet2 msdbDataSet2;
        private System.Windows.Forms.BindingSource gENEREBindingSource;
        private msdbDataSet2TableAdapters.GENERETableAdapter gENERETableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn gENEREIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gENERENAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnAddGenere;
        private System.Windows.Forms.Button btnUpdateGenere;
        private System.Windows.Forms.Button btnDeleteGenere;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtGenererId;
        private System.Windows.Forms.TextBox txtGenereName;
        private System.Windows.Forms.Button btnShowGenereDate;
    }
}