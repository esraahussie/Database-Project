﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class ManageGenereForm : Form
    {
        public ManageGenereForm()
        {
            InitializeComponent();
        }

        private void ManageGenere_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'msdbDataSet2.GENERE' table. You can move, or remove it, as needed.
            this.gENERETableAdapter.Fill(this.msdbDataSet2.GENERE);

        }

        private void btnAddGenere_Click(object sender, EventArgs e)
        {
            try
            {
                string genere_id = txtGenererId.Text;
                string genere_name = txtGenereName.Text;


                string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"INSERT INTO [GENERE] 
            (GENERE_ID, GENERE_NAME) 
            VALUES 
            (@genereId, @genereName)";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@genereId", genere_id);
                    cmd.Parameters.AddWithValue("@genereName", genere_name);



                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Genere added successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnUpdateGenere_Click(object sender, EventArgs e)
        {
            string genere_id = txtGenererId.Text;
            string genere_name = txtGenereName.Text;


            string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"UPDATE [GENERE]
                         SET 
                             GENERE_NAME=@genereName 
                         WHERE 
                              GENERE_ID = @genereId";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@genereId", genere_id);
                cmd.Parameters.AddWithValue("@genereName", genere_name);



                con.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                    MessageBox.Show("Genere updated successfully!");
                else
                    MessageBox.Show("No Genere found with the given ID.");
            }
        }

        private void btnDeleteGenere_Click(object sender, EventArgs e)
        {
            string genere_id = txtGenererId.Text;
            if (string.IsNullOrEmpty(genere_id))
            {
                MessageBox.Show("Please enter a valid GENERE_ID to delete.");
                return;
            }
            string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"DELETE FROM [GENERE] WHERE GENERE_ID=@genereId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@genereId", genere_id);
                con.Open();
                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                    MessageBox.Show("Genere deleted successfully!");
                else
                    MessageBox.Show("No Genere found with the given GENERE_ID.");

            }
        }

        private void btnShowGenereDate_Click(object sender, EventArgs e)
        {
            this.gENERETableAdapter.Fill(this.msdbDataSet2.GENERE);
            dataGridView1.DataSource = this.msdbDataSet2.GENERE;

        }
    }
}
