﻿namespace MovieRental
{
    partial class MovieManagmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labell = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMovieId = new System.Windows.Forms.TextBox();
            this.txtMovieYear = new System.Windows.Forms.TextBox();
            this.txtMovieName = new System.Windows.Forms.TextBox();
            this.txtSupplierId = new System.Windows.Forms.TextBox();
            this.txtAdminId = new System.Windows.Forms.TextBox();
            this.txtGenereId = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.btnAddMovie = new System.Windows.Forms.Button();
            this.btnUpdateMovie = new System.Windows.Forms.Button();
            this.brnShowMovies = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.mOVIEBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.msdbDataSet1 = new MovieRental.msdbDataSet2();
            this.mOVIEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mOVIETableAdapter = new MovieRental.msdbDataSet2TableAdapters.MOVIETableAdapter();
            this.gENEREBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gENERETableAdapter = new MovieRental.msdbDataSet2TableAdapters.GENERETableAdapter();
            this.msdbDataSet2 = new MovieRental.msdbDataSet2();
            this.mOVIEBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.mOVIETableAdapter1 = new MovieRental.msdbDataSet2TableAdapters.MOVIETableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.mOVIEIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gENEREIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDMINIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sUPPLIERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mOVIENAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mOVIEYEARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aVAILABILITYDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.pRICEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addeddateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAddedDate = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gENEREBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Movie ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Genere ID";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(37, 126);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(61, 16);
            this.label.TabIndex = 3;
            this.label.Text = "Admin ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Supplier ID";
            // 
            // labell
            // 
            this.labell.AutoSize = true;
            this.labell.Location = new System.Drawing.Point(37, 223);
            this.labell.Name = "labell";
            this.labell.Size = new System.Drawing.Size(84, 16);
            this.labell.TabIndex = 5;
            this.labell.Text = "Movie Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Movie Year";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 303);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Availability";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 333);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Price";
            // 
            // txtMovieId
            // 
            this.txtMovieId.Location = new System.Drawing.Point(121, 41);
            this.txtMovieId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMovieId.Name = "txtMovieId";
            this.txtMovieId.Size = new System.Drawing.Size(100, 22);
            this.txtMovieId.TabIndex = 9;
            // 
            // txtMovieYear
            // 
            this.txtMovieYear.Location = new System.Drawing.Point(121, 260);
            this.txtMovieYear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMovieYear.Name = "txtMovieYear";
            this.txtMovieYear.Size = new System.Drawing.Size(100, 22);
            this.txtMovieYear.TabIndex = 11;
            // 
            // txtMovieName
            // 
            this.txtMovieName.Location = new System.Drawing.Point(121, 223);
            this.txtMovieName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMovieName.Name = "txtMovieName";
            this.txtMovieName.Size = new System.Drawing.Size(100, 22);
            this.txtMovieName.TabIndex = 12;
            // 
            // txtSupplierId
            // 
            this.txtSupplierId.Location = new System.Drawing.Point(121, 175);
            this.txtSupplierId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSupplierId.Name = "txtSupplierId";
            this.txtSupplierId.Size = new System.Drawing.Size(100, 22);
            this.txtSupplierId.TabIndex = 13;
            // 
            // txtAdminId
            // 
            this.txtAdminId.Location = new System.Drawing.Point(121, 126);
            this.txtAdminId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAdminId.Name = "txtAdminId";
            this.txtAdminId.Size = new System.Drawing.Size(100, 22);
            this.txtAdminId.TabIndex = 14;
            // 
            // txtGenereId
            // 
            this.txtGenereId.Location = new System.Drawing.Point(121, 80);
            this.txtGenereId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGenereId.Name = "txtGenereId";
            this.txtGenereId.Size = new System.Drawing.Size(100, 22);
            this.txtGenereId.TabIndex = 15;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(121, 333);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(100, 22);
            this.txtPrice.TabIndex = 16;
            // 
            // btnAddMovie
            // 
            this.btnAddMovie.Location = new System.Drawing.Point(39, 399);
            this.btnAddMovie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddMovie.Name = "btnAddMovie";
            this.btnAddMovie.Size = new System.Drawing.Size(116, 30);
            this.btnAddMovie.TabIndex = 17;
            this.btnAddMovie.Text = "Add movie";
            this.btnAddMovie.UseVisualStyleBackColor = true;
            this.btnAddMovie.Click += new System.EventHandler(this.btnAddMovie_Click);
            // 
            // btnUpdateMovie
            // 
            this.btnUpdateMovie.Location = new System.Drawing.Point(329, 406);
            this.btnUpdateMovie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnUpdateMovie.Name = "btnUpdateMovie";
            this.btnUpdateMovie.Size = new System.Drawing.Size(113, 31);
            this.btnUpdateMovie.TabIndex = 18;
            this.btnUpdateMovie.Text = "UpdateMovie";
            this.btnUpdateMovie.UseVisualStyleBackColor = true;
            this.btnUpdateMovie.Click += new System.EventHandler(this.btnUpdateMovie_Click);
            // 
            // brnShowMovies
            // 
            this.brnShowMovies.Location = new System.Drawing.Point(429, 260);
            this.brnShowMovies.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.brnShowMovies.Name = "brnShowMovies";
            this.brnShowMovies.Size = new System.Drawing.Size(117, 32);
            this.brnShowMovies.TabIndex = 19;
            this.brnShowMovies.Text = "Show Movies";
            this.brnShowMovies.UseVisualStyleBackColor = true;
            this.brnShowMovies.Click += new System.EventHandler(this.brnShowMovies_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(126, 303);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(95, 20);
            this.checkBox1.TabIndex = 20;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(189, 406);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(114, 23);
            this.btnDelete.TabIndex = 21;
            this.btnDelete.Text = "Delete Movie";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // mOVIEBindingSource1
            // 
            this.mOVIEBindingSource1.DataMember = "MOVIE";
            this.mOVIEBindingSource1.DataSource = this.msdbDataSet1;
            // 
            // msdbDataSet1
            // 
            this.msdbDataSet1.DataSetName = "msdbDataSet1";
            this.msdbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mOVIEBindingSource
            // 
            this.mOVIEBindingSource.DataMember = "MOVIE";
            this.mOVIEBindingSource.DataSource = this.msdbDataSet1;
            // 
            // mOVIETableAdapter
            // 
            this.mOVIETableAdapter.ClearBeforeFill = true;
            // 
            // gENEREBindingSource
            // 
            this.gENEREBindingSource.DataMember = "GENERE";
            this.gENEREBindingSource.DataSource = this.msdbDataSet1;
            // 
            // gENERETableAdapter
            // 
            this.gENERETableAdapter.ClearBeforeFill = true;
            // 
            // msdbDataSet2
            // 
            this.msdbDataSet2.DataSetName = "msdbDataSet2";
            this.msdbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mOVIEBindingSource2
            // 
            this.mOVIEBindingSource2.DataMember = "MOVIE";
            this.mOVIEBindingSource2.DataSource = this.msdbDataSet2;
            // 
            // mOVIETableAdapter1
            // 
            this.mOVIETableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mOVIEIDDataGridViewTextBoxColumn,
            this.gENEREIDDataGridViewTextBoxColumn,
            this.aDMINIDDataGridViewTextBoxColumn,
            this.sUPPLIERIDDataGridViewTextBoxColumn,
            this.mOVIENAMEDataGridViewTextBoxColumn,
            this.mOVIEYEARDataGridViewTextBoxColumn,
            this.aVAILABILITYDataGridViewCheckBoxColumn,
            this.pRICEDataGridViewTextBoxColumn,
            this.addeddateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.mOVIEBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(257, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(531, 198);
            this.dataGridView1.TabIndex = 22;
            // 
            // mOVIEIDDataGridViewTextBoxColumn
            // 
            this.mOVIEIDDataGridViewTextBoxColumn.DataPropertyName = "MOVIE_ID";
            this.mOVIEIDDataGridViewTextBoxColumn.HeaderText = "MOVIE_ID";
            this.mOVIEIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mOVIEIDDataGridViewTextBoxColumn.Name = "mOVIEIDDataGridViewTextBoxColumn";
            this.mOVIEIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // gENEREIDDataGridViewTextBoxColumn
            // 
            this.gENEREIDDataGridViewTextBoxColumn.DataPropertyName = "GENERE_ID";
            this.gENEREIDDataGridViewTextBoxColumn.HeaderText = "GENERE_ID";
            this.gENEREIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gENEREIDDataGridViewTextBoxColumn.Name = "gENEREIDDataGridViewTextBoxColumn";
            this.gENEREIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aDMINIDDataGridViewTextBoxColumn
            // 
            this.aDMINIDDataGridViewTextBoxColumn.DataPropertyName = "ADMIN_ID";
            this.aDMINIDDataGridViewTextBoxColumn.HeaderText = "ADMIN_ID";
            this.aDMINIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aDMINIDDataGridViewTextBoxColumn.Name = "aDMINIDDataGridViewTextBoxColumn";
            this.aDMINIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // sUPPLIERIDDataGridViewTextBoxColumn
            // 
            this.sUPPLIERIDDataGridViewTextBoxColumn.DataPropertyName = "SUPPLIER_ID";
            this.sUPPLIERIDDataGridViewTextBoxColumn.HeaderText = "SUPPLIER_ID";
            this.sUPPLIERIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sUPPLIERIDDataGridViewTextBoxColumn.Name = "sUPPLIERIDDataGridViewTextBoxColumn";
            this.sUPPLIERIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // mOVIENAMEDataGridViewTextBoxColumn
            // 
            this.mOVIENAMEDataGridViewTextBoxColumn.DataPropertyName = "MOVIE_NAME";
            this.mOVIENAMEDataGridViewTextBoxColumn.HeaderText = "MOVIE_NAME";
            this.mOVIENAMEDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mOVIENAMEDataGridViewTextBoxColumn.Name = "mOVIENAMEDataGridViewTextBoxColumn";
            this.mOVIENAMEDataGridViewTextBoxColumn.Width = 125;
            // 
            // mOVIEYEARDataGridViewTextBoxColumn
            // 
            this.mOVIEYEARDataGridViewTextBoxColumn.DataPropertyName = "MOVIE_YEAR";
            this.mOVIEYEARDataGridViewTextBoxColumn.HeaderText = "MOVIE_YEAR";
            this.mOVIEYEARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mOVIEYEARDataGridViewTextBoxColumn.Name = "mOVIEYEARDataGridViewTextBoxColumn";
            this.mOVIEYEARDataGridViewTextBoxColumn.Width = 125;
            // 
            // aVAILABILITYDataGridViewCheckBoxColumn
            // 
            this.aVAILABILITYDataGridViewCheckBoxColumn.DataPropertyName = "AVAILABILITY";
            this.aVAILABILITYDataGridViewCheckBoxColumn.HeaderText = "AVAILABILITY";
            this.aVAILABILITYDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.aVAILABILITYDataGridViewCheckBoxColumn.Name = "aVAILABILITYDataGridViewCheckBoxColumn";
            this.aVAILABILITYDataGridViewCheckBoxColumn.Width = 125;
            // 
            // pRICEDataGridViewTextBoxColumn
            // 
            this.pRICEDataGridViewTextBoxColumn.DataPropertyName = "PRICE";
            this.pRICEDataGridViewTextBoxColumn.HeaderText = "PRICE";
            this.pRICEDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pRICEDataGridViewTextBoxColumn.Name = "pRICEDataGridViewTextBoxColumn";
            this.pRICEDataGridViewTextBoxColumn.Width = 125;
            // 
            // addeddateDataGridViewTextBoxColumn
            // 
            this.addeddateDataGridViewTextBoxColumn.DataPropertyName = "added_date";
            this.addeddateDataGridViewTextBoxColumn.HeaderText = "added_date";
            this.addeddateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addeddateDataGridViewTextBoxColumn.Name = "addeddateDataGridViewTextBoxColumn";
            this.addeddateDataGridViewTextBoxColumn.Width = 125;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 362);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "added date";
            // 
            // txtAddedDate
            // 
            this.txtAddedDate.Location = new System.Drawing.Point(121, 362);
            this.txtAddedDate.Name = "txtAddedDate";
            this.txtAddedDate.Size = new System.Drawing.Size(100, 22);
            this.txtAddedDate.TabIndex = 24;
            // 
            // MovieManagmentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtAddedDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.brnShowMovies);
            this.Controls.Add(this.btnUpdateMovie);
            this.Controls.Add(this.btnAddMovie);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtGenereId);
            this.Controls.Add(this.txtAdminId);
            this.Controls.Add(this.txtSupplierId);
            this.Controls.Add(this.txtMovieName);
            this.Controls.Add(this.txtMovieYear);
            this.Controls.Add(this.txtMovieId);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labell);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MovieManagmentForm";
            this.Text = " ";
            this.Load += new System.EventHandler(this.MovieManagmentForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gENEREBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mOVIEBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private msdbDataSet2 msdbDataSet1;
        private System.Windows.Forms.BindingSource mOVIEBindingSource;
        private msdbDataSet2TableAdapters.MOVIETableAdapter mOVIETableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labell;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMovieId;
        private System.Windows.Forms.TextBox txtMovieYear;
        private System.Windows.Forms.TextBox txtSupplierId;
        private System.Windows.Forms.TextBox txtAdminId;
        private System.Windows.Forms.TextBox txtGenereId;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Button btnAddMovie;
        private System.Windows.Forms.Button btnUpdateMovie;
        private System.Windows.Forms.Button brnShowMovies;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.BindingSource gENEREBindingSource;
        private msdbDataSet2TableAdapters.GENERETableAdapter gENERETableAdapter;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.BindingSource mOVIEBindingSource1;
        private msdbDataSet2 msdbDataSet2;
        private System.Windows.Forms.BindingSource mOVIEBindingSource2;
        private msdbDataSet2TableAdapters.MOVIETableAdapter mOVIETableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mOVIEIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gENEREIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDMINIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sUPPLIERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mOVIENAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mOVIEYEARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn aVAILABILITYDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pRICEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addeddateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAddedDate;
        private System.Windows.Forms.TextBox txtMovieName;
    }
}