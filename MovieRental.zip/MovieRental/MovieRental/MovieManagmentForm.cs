﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class MovieManagmentForm : Form
    {
        public MovieManagmentForm()
        {
            InitializeComponent();
        }

        private void MovieManagmentForm_Load(object sender, EventArgs e)
        {
            this.mOVIETableAdapter1.Fill(this.msdbDataSet2.MOVIE);
        }

        private void brnShowMovies_Click(object sender, EventArgs e)
        {
            this.mOVIETableAdapter1.Fill(this.msdbDataSet2.MOVIE);
            dataGridView1.DataSource = this.msdbDataSet2.MOVIE;
        }


        private void btnAddMovie_Click(object sender, EventArgs e)
        {
            try
            {
                string movie_name = txtMovieName.Text.Trim().Trim('"');

                if (string.IsNullOrWhiteSpace(movie_name))
                {
                    MessageBox.Show("Please enter a valid Movie Name.");
                    return;
                }

                if (!int.TryParse(txtMovieId.Text.Trim(), out int movie_id) ||
                    !int.TryParse(txtGenereId.Text.Trim(), out int genere_id) ||
                    !int.TryParse(txtAdminId.Text.Trim(), out int admin_id) ||
                    !int.TryParse(txtSupplierId.Text.Trim(), out int supplier_id) ||
                    !int.TryParse(txtMovieYear.Text.Trim(), out int movie_year) ||
                    !decimal.TryParse(txtPrice.Text.Trim(), out decimal price) ||
                    !DateTime.TryParse(txtAddedDate.Text.Trim(), out DateTime added_date))
                {
                    MessageBox.Show("Please enter valid numeric and date values.");
                    return;
                }

                bool availability = checkBox1.Checked;

                string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"INSERT INTO [MOVIE] 
                        (MOVIE_ID, GENERE_ID, ADMIN_ID, SUPPLIER_ID, MOVIE_NAME, MOVIE_YEAR, AVAILABILITY, PRICE, added_date) 
                        VALUES 
                        (@movieID, @genereID, @adminID, @supplierID, @movieName, @movieYear, @avail, @price, @addedDate)";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@movieID", movie_id);
                    cmd.Parameters.AddWithValue("@genereID", genere_id);
                    cmd.Parameters.AddWithValue("@adminID", admin_id);
                    cmd.Parameters.AddWithValue("@supplierID", supplier_id);
                    cmd.Parameters.AddWithValue("@movieName", movie_name);
                    cmd.Parameters.AddWithValue("@movieYear", movie_year);
                    cmd.Parameters.AddWithValue("@avail", availability);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@addedDate", added_date);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Movie added successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnUpdateMovie_Click(object sender, EventArgs e)
        {
            try
            {
                string movie_name = labell.Text.Trim().Trim('"');

                if (string.IsNullOrWhiteSpace(txtMovieId.Text))
                {
                    MessageBox.Show("Please enter the Movie ID to update.");
                    return;
                }

                if (!int.TryParse(txtMovieId.Text.Trim(), out int movie_id) ||
                    !int.TryParse(txtGenereId.Text.Trim(), out int genere_id) ||
                    !int.TryParse(txtAdminId.Text.Trim(), out int admin_id) ||
                    !int.TryParse(txtSupplierId.Text.Trim(), out int supplier_id) ||
                    !int.TryParse(txtMovieYear.Text.Trim(), out int movie_year) ||
                    !decimal.TryParse(txtPrice.Text.Trim(), out decimal price) ||
                    !DateTime.TryParse(txtAddedDate.Text.Trim(), out DateTime added_date))
                {
                    MessageBox.Show("Please enter valid numeric and date values.");
                    return;
                }

                bool availability = checkBox1.Checked;

                string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"UPDATE [MOVIE]
                        SET GENERE_ID = @genereId,
                            ADMIN_ID = @adminId,
                            SUPPLIER_ID = @supplierId,
                            MOVIE_NAME = @movieName,
                            MOVIE_YEAR = @movieYear,
                            AVAILABILITY = @avail,
                            PRICE = @price,
                            added_date = @addedDate
                        WHERE MOVIE_ID = @movieId";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@genereId", genere_id);
                    cmd.Parameters.AddWithValue("@adminId", admin_id);
                    cmd.Parameters.AddWithValue("@supplierId", supplier_id);
                    cmd.Parameters.AddWithValue("@movieName", movie_name);
                    cmd.Parameters.AddWithValue("@movieYear", movie_year);
                    cmd.Parameters.AddWithValue("@avail", availability);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@addedDate", added_date);
                    cmd.Parameters.AddWithValue("@movieId", movie_id);

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Movie updated successfully!");
                    else
                        MessageBox.Show("No movie found with the given Movie ID.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtMovieId.Text = row.Cells["MOVIE_ID"].Value.ToString();
                txtGenereId.Text = row.Cells["GENERE_ID"].Value.ToString();
                txtAdminId.Text = row.Cells["ADMIN_ID"].Value.ToString();
                txtSupplierId.Text = row.Cells["SUPPLIER_ID"].Value.ToString();
                labell.Text = row.Cells["MOVIE_NAME"].Value.ToString().Trim('"');
                txtMovieYear.Text = row.Cells["MOVIE_YEAR"].Value.ToString();
                checkBox1.Checked = Convert.ToBoolean(row.Cells["AVAILABILITY"].Value);
                txtPrice.Text = row.Cells["PRICE"].Value.ToString();
                txtAddedDate.Text = Convert.ToDateTime(row.Cells["added_date"].Value).ToString("yyyy-MM-dd");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string movie_id= txtMovieId.Text;
            if (string.IsNullOrWhiteSpace(movie_id))
            {
                MessageBox.Show("Please enter a valid MOVIE_ID to delete.");
                return;
            }
            string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"DELETE FROM [MOVIE] WHERE  MOVIE_ID=@movieId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@movieId", movie_id);

                con.Open();
                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                    MessageBox.Show("Movie deleted successfully!");
                else
                    MessageBox.Show("No user found with the given MOVIE_ID.");
            }
        }
    }
}
