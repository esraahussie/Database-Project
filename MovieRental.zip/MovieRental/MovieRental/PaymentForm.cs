﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class PaymentForm : Form
    {
        private string movieName;
        public PaymentForm(string selectedMovie)
        {
            InitializeComponent();
            movieName = selectedMovie;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userId = textBox1.Text.Trim();
            string creditCard = textBox2.Text.Trim();
            string bin = textBox3.Text.Trim();

            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(creditCard) || string.IsNullOrEmpty(bin))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            string connectionString = "Data Source=DESKTOP-VF0BM3L\\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

            string updateUserQuery = "UPDATE Users SET CREDIT_CARD = @creditCard WHERE USER_ID = @userId";
            string insertRentQuery = "INSERT INTO Rentals (USER_ID, MOVIE_NAME, RENT_DATE) VALUES (@userId, @movieName, @rentDate)";
            string updateMovieAvailabilityQuery = "UPDATE Movies SET AVAILABILITY = 0 WHERE MOVIE_NAME = @movieName";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    using (SqlCommand cmdUpdate = new SqlCommand(updateUserQuery, conn))
                    {
                        cmdUpdate.Parameters.AddWithValue("@creditCard", creditCard);
                        cmdUpdate.Parameters.AddWithValue("@userId", userId);
                        int rowsAffected = cmdUpdate.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            MessageBox.Show("User ID not found.");
                            return;
                        }
                    }

                    using (SqlCommand cmdInsert = new SqlCommand(insertRentQuery, conn))
                    {
                        cmdInsert.Parameters.AddWithValue("@userId", userId);
                        cmdInsert.Parameters.AddWithValue("@movieName", movieName);
                        cmdInsert.Parameters.AddWithValue("@rentDate", DateTime.Now);

                        cmdInsert.ExecuteNonQuery();
                    }

                    using (SqlCommand cmdUpdateMovie = new SqlCommand(updateMovieAvailabilityQuery, conn))
                    {
                        cmdUpdateMovie.Parameters.AddWithValue("@movieName", movieName);
                        cmdUpdateMovie.ExecuteNonQuery();
                    }

                    MessageBox.Show("Rented successfully!");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error processing payment: " + ex.Message);
            }
        }
    }
}