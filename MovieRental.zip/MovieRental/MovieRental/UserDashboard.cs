﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class UserDashboard : Form
    {
        private string connectionString = "Data Source=DESKTOP-VF0BM3L\\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

        public UserDashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            string searchField = comboBox1.SelectedItem?.ToString();
            string searchValue = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(searchField) || string.IsNullOrEmpty(searchValue))
            {
                MessageBox.Show("Please select search criteria and enter a search value.");
                return;
            }

            string query = "";

            switch (searchField)
            {
                case "Year":
                    query = "SELECT MOVIE_NAME FROM Movies WHERE MOVIE_YEAR = @value";
                    break;
                case "Title":
                    query = "SELECT MOVIE_NAME FROM Movies WHERE MOVIE_NAME LIKE '%' + @value + '%'";
                    break;
                case "Actor Name ":
                    query = "SELECT MOVIE_NAME FROM Movies WHERE ACTOR_NAME LIKE '%' + @value + '%'";
                    break;
                case "Supplier":
                    query = "SELECT MOVIE_NAME FROM Movies WHERE SUPPLIER_NAME LIKE '%' + @value + '%'";
                    break;
                default:
                    MessageBox.Show("Invalid search field selected.");
                    return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                if (searchField == "Year")
                {
                    if (!int.TryParse(searchValue, out int year))
                    {
                        MessageBox.Show("Please enter a valid year.");
                        return;
                    }
                    cmd.Parameters.AddWithValue("@value", year);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@value", searchValue);
                }

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        listBox1.Items.Add(reader["MOVIE_NAME"].ToString());
                    }

                    if (listBox1.Items.Count == 0)
                        MessageBox.Show("No movies found matching the search criteria.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        
        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("Please select a movie.");
                return;
            }

            string selectedMovie = listBox1.SelectedItem.ToString();
            DescriptionForm descForm = new DescriptionForm(selectedMovie);
            descForm.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DisplayMovies displayMovies = new DisplayMovies();
            displayMovies.Show();
        }

        private void UserDashboard_Load(object sender, EventArgs e)
        {
        }

    }
}