﻿namespace MovieRental
{
    partial class UserManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.uSERIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDMINIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMAILDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bUSSINESSADDRESSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pHONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rESIDENCEADDRESSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bILLINGADDRESSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cREDITCARDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.msdbDataSet = new MovieRental.msdbDataSet2();
            this.uSERTableAdapter = new MovieRental.msdbDataSet2TableAdapters.USERTableAdapter();
            this.btnLoadUser = new System.Windows.Forms.Button();
            this.btnUpdateUsers = new System.Windows.Forms.Button();
            this.btnDeleteUsers = new System.Windows.Forms.Button();
            this.btnShowData = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtBusinessAddress = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAdminID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtResidenceAddress = new System.Windows.Forms.TextBox();
            this.txtCreditCard = new System.Windows.Forms.TextBox();
            this.txtBillingAddress = new System.Windows.Forms.TextBox();
            this.msdbDataSet2 = new MovieRental.msdbDataSet2();
            this.uSERBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.uSERTableAdapter1 = new MovieRental.msdbDataSet2TableAdapters.USERTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.uSERIDDataGridViewTextBoxColumn,
            this.aDMINIDDataGridViewTextBoxColumn,
            this.eMAILDataGridViewTextBoxColumn,
            this.bUSSINESSADDRESSDataGridViewTextBoxColumn,
            this.pHONEDataGridViewTextBoxColumn,
            this.rESIDENCEADDRESSDataGridViewTextBoxColumn,
            this.bILLINGADDRESSDataGridViewTextBoxColumn,
            this.cREDITCARDDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.uSERBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(367, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(612, 236);
            this.dataGridView1.TabIndex = 0;
            // 
            // uSERIDDataGridViewTextBoxColumn
            // 
            this.uSERIDDataGridViewTextBoxColumn.DataPropertyName = "USER_ID";
            this.uSERIDDataGridViewTextBoxColumn.HeaderText = "USER_ID";
            this.uSERIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.uSERIDDataGridViewTextBoxColumn.Name = "uSERIDDataGridViewTextBoxColumn";
            this.uSERIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aDMINIDDataGridViewTextBoxColumn
            // 
            this.aDMINIDDataGridViewTextBoxColumn.DataPropertyName = "ADMIN_ID";
            this.aDMINIDDataGridViewTextBoxColumn.HeaderText = "ADMIN_ID";
            this.aDMINIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aDMINIDDataGridViewTextBoxColumn.Name = "aDMINIDDataGridViewTextBoxColumn";
            this.aDMINIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // eMAILDataGridViewTextBoxColumn
            // 
            this.eMAILDataGridViewTextBoxColumn.DataPropertyName = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.HeaderText = "EMAIL";
            this.eMAILDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.eMAILDataGridViewTextBoxColumn.Name = "eMAILDataGridViewTextBoxColumn";
            this.eMAILDataGridViewTextBoxColumn.Width = 125;
            // 
            // bUSSINESSADDRESSDataGridViewTextBoxColumn
            // 
            this.bUSSINESSADDRESSDataGridViewTextBoxColumn.DataPropertyName = "BUSSINESS_ADDRESS";
            this.bUSSINESSADDRESSDataGridViewTextBoxColumn.HeaderText = "BUSSINESS_ADDRESS";
            this.bUSSINESSADDRESSDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bUSSINESSADDRESSDataGridViewTextBoxColumn.Name = "bUSSINESSADDRESSDataGridViewTextBoxColumn";
            this.bUSSINESSADDRESSDataGridViewTextBoxColumn.Width = 125;
            // 
            // pHONEDataGridViewTextBoxColumn
            // 
            this.pHONEDataGridViewTextBoxColumn.DataPropertyName = "PHONE";
            this.pHONEDataGridViewTextBoxColumn.HeaderText = "PHONE";
            this.pHONEDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.pHONEDataGridViewTextBoxColumn.Name = "pHONEDataGridViewTextBoxColumn";
            this.pHONEDataGridViewTextBoxColumn.Width = 125;
            // 
            // rESIDENCEADDRESSDataGridViewTextBoxColumn
            // 
            this.rESIDENCEADDRESSDataGridViewTextBoxColumn.DataPropertyName = "RESIDENCE_ADDRESS";
            this.rESIDENCEADDRESSDataGridViewTextBoxColumn.HeaderText = "RESIDENCE_ADDRESS";
            this.rESIDENCEADDRESSDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.rESIDENCEADDRESSDataGridViewTextBoxColumn.Name = "rESIDENCEADDRESSDataGridViewTextBoxColumn";
            this.rESIDENCEADDRESSDataGridViewTextBoxColumn.Width = 125;
            // 
            // bILLINGADDRESSDataGridViewTextBoxColumn
            // 
            this.bILLINGADDRESSDataGridViewTextBoxColumn.DataPropertyName = "BILLING_ADDRESS";
            this.bILLINGADDRESSDataGridViewTextBoxColumn.HeaderText = "BILLING_ADDRESS";
            this.bILLINGADDRESSDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bILLINGADDRESSDataGridViewTextBoxColumn.Name = "bILLINGADDRESSDataGridViewTextBoxColumn";
            this.bILLINGADDRESSDataGridViewTextBoxColumn.Width = 125;
            // 
            // cREDITCARDDataGridViewTextBoxColumn
            // 
            this.cREDITCARDDataGridViewTextBoxColumn.DataPropertyName = "CREDIT_CARD";
            this.cREDITCARDDataGridViewTextBoxColumn.HeaderText = "CREDIT_CARD";
            this.cREDITCARDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cREDITCARDDataGridViewTextBoxColumn.Name = "cREDITCARDDataGridViewTextBoxColumn";
            this.cREDITCARDDataGridViewTextBoxColumn.Width = 125;
            // 
            // uSERBindingSource
            // 
            this.uSERBindingSource.DataMember = "USER";
            this.uSERBindingSource.DataSource = this.msdbDataSet;
            // 
            // msdbDataSet
            // 
            this.msdbDataSet.DataSetName = "msdbDataSet";
            this.msdbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uSERTableAdapter
            // 
            this.uSERTableAdapter.ClearBeforeFill = true;
            // 
            // btnLoadUser
            // 
            this.btnLoadUser.Location = new System.Drawing.Point(609, 309);
            this.btnLoadUser.Name = "btnLoadUser";
            this.btnLoadUser.Size = new System.Drawing.Size(97, 23);
            this.btnLoadUser.TabIndex = 1;
            this.btnLoadUser.Text = "Load Users\t";
            this.btnLoadUser.UseVisualStyleBackColor = true;
            this.btnLoadUser.Click += new System.EventHandler(this.btnLoadUser_Click);
            // 
            // btnUpdateUsers
            // 
            this.btnUpdateUsers.Location = new System.Drawing.Point(770, 309);
            this.btnUpdateUsers.Name = "btnUpdateUsers";
            this.btnUpdateUsers.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateUsers.TabIndex = 2;
            this.btnUpdateUsers.Text = "Update";
            this.btnUpdateUsers.UseVisualStyleBackColor = true;
            this.btnUpdateUsers.Click += new System.EventHandler(this.btnUpdateUsers_Click);
            // 
            // btnDeleteUsers
            // 
            this.btnDeleteUsers.Location = new System.Drawing.Point(904, 309);
            this.btnDeleteUsers.Name = "btnDeleteUsers";
            this.btnDeleteUsers.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteUsers.TabIndex = 3;
            this.btnDeleteUsers.Text = "Delete";
            this.btnDeleteUsers.UseVisualStyleBackColor = true;
            this.btnDeleteUsers.Click += new System.EventHandler(this.btnDeleteUsers_Click);
            // 
            // btnShowData
            // 
            this.btnShowData.Location = new System.Drawing.Point(743, 396);
            this.btnShowData.Name = "btnShowData";
            this.btnShowData.Size = new System.Drawing.Size(102, 23);
            this.btnShowData.TabIndex = 4;
            this.btnShowData.Text = "show data";
            this.btnShowData.UseVisualStyleBackColor = true;
            this.btnShowData.Click += new System.EventHandler(this.btnShowData_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Phone";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "business address";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(162, 117);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(159, 22);
            this.txtEmail.TabIndex = 8;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(162, 219);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(159, 22);
            this.txtPhone.TabIndex = 9;
            // 
            // txtBusinessAddress
            // 
            this.txtBusinessAddress.Location = new System.Drawing.Point(162, 170);
            this.txtBusinessAddress.Name = "txtBusinessAddress";
            this.txtBusinessAddress.Size = new System.Drawing.Size(159, 22);
            this.txtBusinessAddress.TabIndex = 10;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(162, 19);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(159, 22);
            this.txtID.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 16);
            this.label4.TabIndex = 12;
            this.label4.Text = "User ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Admin ID";
            // 
            // txtAdminID
            // 
            this.txtAdminID.Location = new System.Drawing.Point(162, 71);
            this.txtAdminID.Name = "txtAdminID";
            this.txtAdminID.Size = new System.Drawing.Size(159, 22);
            this.txtAdminID.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 16);
            this.label6.TabIndex = 15;
            this.label6.Text = "residenceAddress";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 316);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "billingAddress";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(45, 368);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "creditCard";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txtResidenceAddress
            // 
            this.txtResidenceAddress.Location = new System.Drawing.Point(162, 263);
            this.txtResidenceAddress.Name = "txtResidenceAddress";
            this.txtResidenceAddress.Size = new System.Drawing.Size(159, 22);
            this.txtResidenceAddress.TabIndex = 18;
            // 
            // txtCreditCard
            // 
            this.txtCreditCard.Location = new System.Drawing.Point(162, 362);
            this.txtCreditCard.Name = "txtCreditCard";
            this.txtCreditCard.Size = new System.Drawing.Size(159, 22);
            this.txtCreditCard.TabIndex = 19;
            // 
            // txtBillingAddress
            // 
            this.txtBillingAddress.Location = new System.Drawing.Point(162, 316);
            this.txtBillingAddress.Name = "txtBillingAddress";
            this.txtBillingAddress.Size = new System.Drawing.Size(159, 22);
            this.txtBillingAddress.TabIndex = 20;
            // 
            // msdbDataSet2
            // 
            this.msdbDataSet2.DataSetName = "msdbDataSet2";
            this.msdbDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uSERBindingSource1
            // 
            this.uSERBindingSource1.DataMember = "USER";
            this.uSERBindingSource1.DataSource = this.msdbDataSet2;
            // 
            // uSERTableAdapter1
            // 
            this.uSERTableAdapter1.ClearBeforeFill = true;
            // 
            // UserManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 723);
            this.Controls.Add(this.txtBillingAddress);
            this.Controls.Add(this.txtCreditCard);
            this.Controls.Add(this.txtResidenceAddress);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAdminID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.txtBusinessAddress);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnShowData);
            this.Controls.Add(this.btnDeleteUsers);
            this.Controls.Add(this.btnUpdateUsers);
            this.Controls.Add(this.btnLoadUser);
            this.Controls.Add(this.dataGridView1);
            this.Name = "UserManagementForm";
            this.Text = "UserManagementForm";
            this.Load += new System.EventHandler(this.UserManagementForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.msdbDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private msdbDataSet2 msdbDataSet;
        private System.Windows.Forms.BindingSource uSERBindingSource;
        private msdbDataSet2TableAdapters.USERTableAdapter uSERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSERIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDMINIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMAILDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bUSSINESSADDRESSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pHONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rESIDENCEADDRESSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bILLINGADDRESSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cREDITCARDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnLoadUser;
        private System.Windows.Forms.Button btnUpdateUsers;
        private System.Windows.Forms.Button btnDeleteUsers;
        private System.Windows.Forms.Button btnShowData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtBusinessAddress;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAdminID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtResidenceAddress;
        private System.Windows.Forms.TextBox txtCreditCard;
        private System.Windows.Forms.TextBox txtBillingAddress;
        private msdbDataSet2 msdbDataSet2;
        private System.Windows.Forms.BindingSource uSERBindingSource1;
        private msdbDataSet2TableAdapters.USERTableAdapter uSERTableAdapter1;
    }
}