﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MovieRental
{
    public partial class UserManagementForm : Form
    {
        public UserManagementForm()
        {
            InitializeComponent();
        }

        private void UserManagementForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'msdbDataSet2.USER' table. You can move, or remove it, as needed.
            this.uSERTableAdapter1.Fill(this.msdbDataSet2.USER);

        }

        private void btnLoadUser_Click(object sender, EventArgs e)
        {
            try
            {
                string user_id = txtID.Text;
                string admin_id = txtAdminID.Text;
                string email = txtEmail.Text;
                string phone = txtPhone.Text;
                string residenceAddress = txtResidenceAddress.Text;
                string businessAddress = txtBusinessAddress.Text;
                string billingAddress = txtBillingAddress.Text;
                string creditCard = txtCreditCard.Text;

                string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"INSERT INTO [USER] 
            (USER_ID, ADMIN_ID, EMAIL, BUSSINESS_ADDRESS, PHONE, RESIDENCE_ADDRESS, BILLING_ADDRESS, CREDIT_CARD) 
            VALUES 
            (@userID, @adminID, @email, @businessAddress, @phone, @residenceAddress, @billingAddress, @creditCard)";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@userID", user_id);
                    cmd.Parameters.AddWithValue("@adminID", admin_id);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@businessAddress", businessAddress);
                    cmd.Parameters.AddWithValue("@phone", phone);
                    cmd.Parameters.AddWithValue("@residenceAddress", residenceAddress);
                    cmd.Parameters.AddWithValue("@billingAddress", billingAddress);

                    // لو المستخدم دخل قيمة للكريدت كارد حطها، لو لأ حط NULL
                    if (string.IsNullOrEmpty(creditCard))
                        cmd.Parameters.AddWithValue("@creditCard", DBNull.Value);
                    else
                        cmd.Parameters.AddWithValue("@creditCard", creditCard);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User added successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnShowData_Click(object sender, EventArgs e)
        {
            this.uSERTableAdapter.Fill(this.msdbDataSet2.USER);
            dataGridView1.DataSource = this.msdbDataSet2.USER;


        }

        private void btnUpdateUsers_Click(object sender, EventArgs e)
        {
            string user_id = txtID.Text;
            string admin_id = txtAdminID.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;
            string residenceAddress = txtResidenceAddress.Text;
            string businessAddress = txtBusinessAddress.Text;
            string billingAddress = txtBillingAddress.Text;
            string creditCard = txtCreditCard.Text;

            string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"UPDATE [USER]
                         SET 
                             ADMIN_ID = @adminID,
                             EMAIL = @email,
                             BUSSINESS_ADDRESS = @businessAddress,
                             PHONE = @phone,
                             RESIDENCE_ADDRESS = @residenceAddress,
                             BILLING_ADDRESS = @billingAddress,
                             CREDIT_CARD = @creditCard
                         WHERE USER_ID = @userID";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@userID", user_id);
                cmd.Parameters.AddWithValue("@adminID", admin_id);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@businessAddress", businessAddress);
                cmd.Parameters.AddWithValue("@phone", phone);
                cmd.Parameters.AddWithValue("@residenceAddress", residenceAddress);
                cmd.Parameters.AddWithValue("@billingAddress", billingAddress);
                cmd.Parameters.AddWithValue("@creditCard", string.IsNullOrEmpty(creditCard) ? (object)DBNull.Value : creditCard);

                con.Open();
                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                    MessageBox.Show("User updated successfully!");
                else
                    MessageBox.Show("No user found with the given ID.");
            }

        }

        private void btnDeleteUsers_Click(object sender, EventArgs e)
        {
            string user_id = txtID.Text;
            if (string.IsNullOrWhiteSpace(user_id))
            {
                MessageBox.Show("Please enter a valid USER_ID to delete.");
                return;
            }
            string connectionString = @"Data Source=DESKTOP-VF0BM3L\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"DELETE FROM [USER] WHERE  USER_ID=@userId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@userId", user_id);

                con.Open();
                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                    MessageBox.Show("User deleted successfully!");
                else
                    MessageBox.Show("No user found with the given USER_ID.");
            }
        }     
    }
}
