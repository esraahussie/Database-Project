﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class UserSignUp : Form
    {
        public UserSignUp()
        {
            InitializeComponent();
            button1.Click += Button1_Click;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string userId = textBox1.Text.Trim();
            string email = textBox6.Text.Trim();
            string businessAddress = textBox5.Text.Trim();
            string phone = textBox4.Text.Trim();
            string residenceAddress = textBox3.Text.Trim();
            string billingAddress = textBox8.Text.Trim();

            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Please fill in at least ID and Email.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string connectionString = "Data Source=DESKTOP-VF0BM3L\\MSSQLSERVER2;Initial Catalog=msdb;Integrated Security=True";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"INSERT INTO Users 
                        (USER_ID, EMAIL, BUSINESS_ADDRESS, PHONE, RESIDENCE_ADDRESS, BILLING_ADDRESS) 
                        VALUES (@UserId, @Email, @BusinessAddress, @Phone, @ResidenceAddress, @BillingAddress)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserId", userId);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@BusinessAddress", businessAddress);
                        cmd.Parameters.AddWithValue("@Phone", phone);
                        cmd.Parameters.AddWithValue("@ResidenceAddress", residenceAddress);
                        cmd.Parameters.AddWithValue("@BillingAddress", billingAddress);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User registered successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            UserDashboard dashboard = new UserDashboard();
                            dashboard.Show();

                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Failed to register user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UserSignUp_Load(object sender, EventArgs e)
        {

        }
    }
}