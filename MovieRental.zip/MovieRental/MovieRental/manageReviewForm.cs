﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class manageReviewForm : Form
    {
        public manageReviewForm()
        {
            InitializeComponent();
        }

        private void manageReviewForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'msdbDataSet2.REVIEW' table. You can move, or remove it, as needed.
            this.rEVIEWTableAdapter.Fill(this.msdbDataSet2.REVIEW);

        }
    }
}
