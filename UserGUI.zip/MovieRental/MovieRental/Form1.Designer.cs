﻿namespace MovieRental
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            namePro = new Label();
            label2 = new Label();
            btnLogin = new Button();
            btnSignUp = new Button();
            chooselogsign = new Label();
            SuspendLayout();
            // 
            // namePro
            // 
            namePro.AutoSize = true;
            namePro.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            namePro.Location = new Point(119, 46);
            namePro.Name = "namePro";
            namePro.Size = new Size(575, 57);
            namePro.TabIndex = 0;
            namePro.Text = "🎬 Movie Rental System 🎬";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label2.Location = new Point(166, 164);
            label2.Name = "label2";
            label2.Size = new Size(463, 35);
            label2.TabIndex = 1;
            label2.Text = "Welcome to the Movie Rental System!";
            label2.Click += label2_Click;
            // 
            // btnLogin
            // 
            btnLogin.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnLogin.Location = new Point(119, 310);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(159, 63);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "LogIn";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnSignUp
            // 
            btnSignUp.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnSignUp.Location = new Point(484, 310);
            btnSignUp.Name = "btnSignUp";
            btnSignUp.Size = new Size(162, 63);
            btnSignUp.TabIndex = 3;
            btnSignUp.Text = "SignUp";
            btnSignUp.UseVisualStyleBackColor = true;
            btnSignUp.Click += btnSignUp_Click;
            // 
            // chooselogsign
            // 
            chooselogsign.AutoSize = true;
            chooselogsign.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            chooselogsign.Location = new Point(341, 245);
            chooselogsign.Name = "chooselogsign";
            chooselogsign.Size = new Size(115, 35);
            chooselogsign.TabIndex = 4;
            chooselogsign.Text = "Choose :";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(827, 471);
            Controls.Add(chooselogsign);
            Controls.Add(btnSignUp);
            Controls.Add(btnLogin);
            Controls.Add(label2);
            Controls.Add(namePro);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label namePro;
        private Label label2;
        private Button btnLogin;
        private Button btnSignUp;
        private Label chooselogsign;
    }
}
