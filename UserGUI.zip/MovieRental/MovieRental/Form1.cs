using System.Data.SqlClient;

namespace MovieRental
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }
        
        private void Form1_Load(object sender, EventArgs e) 
        {
            string connectionString = "Data Source=DESKTOP-JSLODRB;Initial Catalog=MovieRentalDB;Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
        }
    }
}
