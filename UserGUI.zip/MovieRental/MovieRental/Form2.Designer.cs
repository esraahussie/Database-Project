﻿namespace MovieRental
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            userlabel = new Label();
            PasswordLabel = new Label();
            ChooseAdmORUs = new ComboBox();
            UserIDBox = new TextBox();
            PasswordBox = new TextBox();
            btnLoginTrue = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // userlabel
            // 
            userlabel.AutoSize = true;
            userlabel.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            userlabel.Location = new Point(67, 118);
            userlabel.Name = "userlabel";
            userlabel.Size = new Size(94, 35);
            userlabel.TabIndex = 0;
            userlabel.Text = "UserID";
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            PasswordLabel.Location = new Point(54, 264);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(128, 35);
            PasswordLabel.TabIndex = 1;
            PasswordLabel.Text = "PassWord";
            // 
            // ChooseAdmORUs
            // 
            ChooseAdmORUs.FormattingEnabled = true;
            ChooseAdmORUs.Location = new Point(557, 171);
            ChooseAdmORUs.Name = "ChooseAdmORUs";
            ChooseAdmORUs.Size = new Size(179, 28);
            ChooseAdmORUs.TabIndex = 2;
            ChooseAdmORUs.SelectedIndexChanged += ChooseAdmORUs_SelectedIndexChanged;
            // 
            // UserIDBox
            // 
            UserIDBox.Location = new Point(223, 119);
            UserIDBox.MaxLength = 6;
            UserIDBox.Name = "UserIDBox";
            UserIDBox.Size = new Size(173, 27);
            UserIDBox.TabIndex = 3;
            // 
            // PasswordBox
            // 
            PasswordBox.Location = new Point(223, 272);
            PasswordBox.MaxLength = 15;
            PasswordBox.Name = "PasswordBox";
            PasswordBox.Size = new Size(173, 27);
            PasswordBox.TabIndex = 4;
            PasswordBox.UseSystemPasswordChar = true;
            // 
            // btnLoginTrue
            // 
            btnLoginTrue.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnLoginTrue.Location = new Point(557, 272);
            btnLoginTrue.Name = "btnLoginTrue";
            btnLoginTrue.Size = new Size(179, 82);
            btnLoginTrue.TabIndex = 5;
            btnLoginTrue.Text = "Submit";
            btnLoginTrue.UseVisualStyleBackColor = true;
            btnLoginTrue.Click += btnLoginTrue_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label1.Location = new Point(557, 110);
            label1.Name = "label1";
            label1.Size = new Size(107, 35);
            label1.TabIndex = 6;
            label1.Text = "Select : ";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(btnLoginTrue);
            Controls.Add(PasswordBox);
            Controls.Add(UserIDBox);
            Controls.Add(ChooseAdmORUs);
            Controls.Add(PasswordLabel);
            Controls.Add(userlabel);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label userlabel;
        private Label PasswordLabel;
        private ComboBox ChooseAdmORUs;
        private TextBox UserIDBox;
        private TextBox PasswordBox;
        private Button btnLoginTrue;
        private Label label1;
    }
}