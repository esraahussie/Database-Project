﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            comboUserORAdmin.Items.Add("Admin");
            comboUserORAdmin.Items.Add("User");

        }

        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            btnTOLogin = new Button();
            BoxUserID = new TextBox();
            BoxPassword = new TextBox();
            comboUserORAdmin = new ComboBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label1.Location = new Point(60, 87);
            label1.Name = "label1";
            label1.Size = new Size(94, 35);
            label1.TabIndex = 0;
            label1.Text = "UserID";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label2.Location = new Point(41, 232);
            label2.Name = "label2";
            label2.Size = new Size(124, 35);
            label2.TabIndex = 1;
            label2.Text = "Password";
            label2.Click += label2_Click;
            // 
            // btnTOLogin
            // 
            btnTOLogin.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnTOLogin.Location = new Point(520, 203);
            btnTOLogin.Name = "btnTOLogin";
            btnTOLogin.Size = new Size(162, 103);
            btnTOLogin.TabIndex = 2;
            btnTOLogin.Text = "Submit..";
            btnTOLogin.UseVisualStyleBackColor = true;
            btnTOLogin.Click += btnTOLogin_Click;
            // 
            // BoxUserID
            // 
            BoxUserID.Location = new Point(192, 94);
            BoxUserID.Name = "BoxUserID";
            BoxUserID.Size = new Size(194, 27);
            BoxUserID.TabIndex = 3;
            // 
            // BoxPassword
            // 
            BoxPassword.Location = new Point(192, 232);
            BoxPassword.Name = "BoxPassword";
            BoxPassword.Size = new Size(194, 27);
            BoxPassword.TabIndex = 4;
            BoxPassword.UseSystemPasswordChar = true;
            // 
            // comboUserORAdmin
            // 
            comboUserORAdmin.FormattingEnabled = true;
            comboUserORAdmin.Location = new Point(531, 94);
            comboUserORAdmin.Name = "comboUserORAdmin";
            comboUserORAdmin.Size = new Size(151, 28);
            comboUserORAdmin.TabIndex = 5;
            comboUserORAdmin.SelectedIndexChanged += comboUserORAdmin_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label3.Location = new Point(417, 87);
            label3.Name = "label3";
            label3.Size = new Size(108, 35);
            label3.TabIndex = 6;
            label3.Text = "Choose:";
            // 
            // Form2
            // 
            ClientSize = new Size(720, 413);
            Controls.Add(label3);
            Controls.Add(comboUserORAdmin);
            Controls.Add(BoxPassword);
            Controls.Add(BoxUserID);
            Controls.Add(btnTOLogin);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            ResumeLayout(false);
            PerformLayout();

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboUserORAdmin_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private Label label1;
        private Label label2;
        private Button btnTOLogin;
        private TextBox BoxUserID;
        private TextBox BoxPassword;
        private ComboBox comboUserORAdmin;
        private Label label3;

        private void btnTOLogin_Click(object sender, EventArgs e)
        {
            string selectedRole = comboUserORAdmin.SelectedItem?.ToString();
            if (selectedRole == null)
            {
                MessageBox.Show("Please select a role.");
                return;
            }
            if (selectedRole == "Admin")
            {

            }
            else if (selectedRole == "User")
            {
                Form4 form4 = new Form4();
                form4.Show();
            }
            else
            {
                MessageBox.Show("Invalid role selected.");
            }

        }
    }
}
