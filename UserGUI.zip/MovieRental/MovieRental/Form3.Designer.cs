﻿namespace MovieRental
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labUserID = new Label();
            labEmail = new Label();
            labPass = new Label();
            comboAdORUser = new ComboBox();
            labChooseAdUs = new Label();
            btnRegister = new Button();
            BoxUserId = new TextBox();
            boxEmail = new TextBox();
            boxPass = new TextBox();
            SuspendLayout();
            // 
            // labUserID
            // 
            labUserID.AutoSize = true;
            labUserID.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            labUserID.Location = new Point(50, 63);
            labUserID.Name = "labUserID";
            labUserID.Size = new Size(94, 35);
            labUserID.TabIndex = 0;
            labUserID.Text = "UserID";
            // 
            // labEmail
            // 
            labEmail.AutoSize = true;
            labEmail.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            labEmail.Location = new Point(50, 181);
            labEmail.Name = "labEmail";
            labEmail.Size = new Size(78, 35);
            labEmail.TabIndex = 1;
            labEmail.Text = "Email";
            // 
            // labPass
            // 
            labPass.AutoSize = true;
            labPass.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            labPass.Location = new Point(34, 316);
            labPass.Name = "labPass";
            labPass.Size = new Size(124, 35);
            labPass.TabIndex = 2;
            labPass.Text = "Password";
            // 
            // comboAdORUser
            // 
            comboAdORUser.FormattingEnabled = true;
            comboAdORUser.Location = new Point(555, 157);
            comboAdORUser.Name = "comboAdORUser";
            comboAdORUser.Size = new Size(181, 28);
            comboAdORUser.TabIndex = 3;
            comboAdORUser.SelectedIndexChanged += comboAdORUser_SelectedIndexChanged;
            // 
            // labChooseAdUs
            // 
            labChooseAdUs.AutoSize = true;
            labChooseAdUs.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            labChooseAdUs.Location = new Point(580, 91);
            labChooseAdUs.Name = "labChooseAdUs";
            labChooseAdUs.Size = new Size(122, 35);
            labChooseAdUs.TabIndex = 4;
            labChooseAdUs.Text = "Choose : ";
            labChooseAdUs.Click += label4_Click;
            // 
            // btnRegister
            // 
            btnRegister.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnRegister.Location = new Point(555, 278);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(181, 110);
            btnRegister.TabIndex = 5;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // BoxUserId
            // 
            BoxUserId.Location = new Point(206, 71);
            BoxUserId.MaxLength = 6;
            BoxUserId.Name = "BoxUserId";
            BoxUserId.Size = new Size(188, 27);
            BoxUserId.TabIndex = 6;
            // 
            // boxEmail
            // 
            boxEmail.Location = new Point(206, 181);
            boxEmail.MaxLength = 25;
            boxEmail.Name = "boxEmail";
            boxEmail.Size = new Size(188, 27);
            boxEmail.TabIndex = 7;
            // 
            // boxPass
            // 
            boxPass.Location = new Point(206, 324);
            boxPass.MaxLength = 15;
            boxPass.Name = "boxPass";
            boxPass.Size = new Size(188, 27);
            boxPass.TabIndex = 8;
            boxPass.UseSystemPasswordChar = true;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(boxPass);
            Controls.Add(boxEmail);
            Controls.Add(BoxUserId);
            Controls.Add(btnRegister);
            Controls.Add(labChooseAdUs);
            Controls.Add(comboAdORUser);
            Controls.Add(labPass);
            Controls.Add(labEmail);
            Controls.Add(labUserID);
            Name = "Form3";
            Text = "Form3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labUserID;
        private Label labEmail;
        private Label labPass;
        private ComboBox comboAdORUser;
        private Label labChooseAdUs;
        private Button btnRegister;
        private TextBox BoxUserId;
        private TextBox boxEmail;
        private TextBox boxPass;
    }
}