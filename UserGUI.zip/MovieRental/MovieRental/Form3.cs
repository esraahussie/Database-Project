﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            comboAdORUser.Items.Add("Admin");
            comboAdORUser.Items.Add("User");
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboAdORUser_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string selectedRole = comboAdORUser.SelectedItem?.ToString();
            if (selectedRole == null)
            {
                MessageBox.Show("Please select a role.");
                return;
            }
            if (selectedRole == "Admin")
            {

            }
            else if (selectedRole == "User")
            {
                Form4 form4 = new Form4();
                form4.Show();
            }
            else
            {
                MessageBox.Show("Invalid role selected.");
            }
        }
    }
}
