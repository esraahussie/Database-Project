﻿namespace MovieRental
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnAdd = new Button();
            btnEdit = new Button();
            labNameMovie = new Label();
            labYearMovie = new Label();
            BoxMovieName = new TextBox();
            BoxMovieYear = new TextBox();
            labEditName = new Label();
            labEditYear = new Label();
            BoxEditName = new TextBox();
            BoxEditYear = new TextBox();
            btnViewDetials = new Button();
            btnSearch = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(369, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(410, 217);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnAdd.Location = new Point(32, 154);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(159, 75);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnEdit
            // 
            btnEdit.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnEdit.Location = new Point(407, 309);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(124, 67);
            btnEdit.TabIndex = 2;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // labNameMovie
            // 
            labNameMovie.AutoSize = true;
            labNameMovie.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labNameMovie.Location = new Point(227, 27);
            labNameMovie.Name = "labNameMovie";
            labNameMovie.Size = new Size(119, 25);
            labNameMovie.TabIndex = 3;
            labNameMovie.Text = "MovieName";
            // 
            // labYearMovie
            // 
            labYearMovie.AutoSize = true;
            labYearMovie.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labYearMovie.Location = new Point(227, 96);
            labYearMovie.Name = "labYearMovie";
            labYearMovie.Size = new Size(105, 25);
            labYearMovie.TabIndex = 4;
            labYearMovie.Text = "MovieYear";
            // 
            // BoxMovieName
            // 
            BoxMovieName.Location = new Point(12, 27);
            BoxMovieName.Name = "BoxMovieName";
            BoxMovieName.Size = new Size(199, 27);
            BoxMovieName.TabIndex = 5;
            // 
            // BoxMovieYear
            // 
            BoxMovieYear.Location = new Point(12, 96);
            BoxMovieYear.Name = "BoxMovieYear";
            BoxMovieYear.Size = new Size(199, 27);
            BoxMovieYear.TabIndex = 6;
            // 
            // labEditName
            // 
            labEditName.AutoSize = true;
            labEditName.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labEditName.Location = new Point(227, 275);
            labEditName.Name = "labEditName";
            labEditName.Size = new Size(119, 25);
            labEditName.TabIndex = 7;
            labEditName.Text = "MovieName";
            // 
            // labEditYear
            // 
            labEditYear.AutoSize = true;
            labEditYear.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labEditYear.Location = new Point(227, 351);
            labEditYear.Name = "labEditYear";
            labEditYear.Size = new Size(105, 25);
            labEditYear.TabIndex = 8;
            labEditYear.Text = "MovieYear";
            // 
            // BoxEditName
            // 
            BoxEditName.Location = new Point(12, 276);
            BoxEditName.Name = "BoxEditName";
            BoxEditName.Size = new Size(199, 27);
            BoxEditName.TabIndex = 9;
            // 
            // BoxEditYear
            // 
            BoxEditYear.Location = new Point(12, 352);
            BoxEditYear.Name = "BoxEditYear";
            BoxEditYear.Size = new Size(199, 27);
            BoxEditYear.TabIndex = 10;
            // 
            // btnViewDetials
            // 
            btnViewDetials.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnViewDetials.Location = new Point(591, 263);
            btnViewDetials.Name = "btnViewDetials";
            btnViewDetials.Size = new Size(188, 66);
            btnViewDetials.TabIndex = 11;
            btnViewDetials.Text = "View Detials";
            btnViewDetials.UseVisualStyleBackColor = true;
            btnViewDetials.Click += btnViewDetials_Click;
            // 
            // btnSearch
            // 
            btnSearch.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnSearch.Location = new Point(594, 371);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(185, 58);
            btnSearch.TabIndex = 12;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSearch);
            Controls.Add(btnViewDetials);
            Controls.Add(BoxEditYear);
            Controls.Add(BoxEditName);
            Controls.Add(labEditYear);
            Controls.Add(labEditName);
            Controls.Add(BoxMovieYear);
            Controls.Add(BoxMovieName);
            Controls.Add(labYearMovie);
            Controls.Add(labNameMovie);
            Controls.Add(btnEdit);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Name = "Form4";
            Text = "Form4";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnAdd;
        private Button btnEdit;
        private Label labNameMovie;
        private Label labYearMovie;
        private TextBox BoxMovieName;
        private TextBox BoxMovieYear;
        private Label labEditName;
        private Label labEditYear;
        private TextBox BoxEditName;
        private TextBox BoxEditYear;
        private Button btnViewDetials;
        private Button btnSearch;
    }
}