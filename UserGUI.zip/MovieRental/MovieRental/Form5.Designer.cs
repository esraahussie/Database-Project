﻿namespace MovieRental
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnRent = new Button();
            btnReview = new Button();
            labReview = new Label();
            labRent = new Label();
            btnToBack = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(28, 53);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(391, 302);
            dataGridView1.TabIndex = 0;
            // 
            // btnRent
            // 
            btnRent.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnRent.Location = new Point(632, 86);
            btnRent.Name = "btnRent";
            btnRent.Size = new Size(156, 81);
            btnRent.TabIndex = 1;
            btnRent.Text = "Rent";
            btnRent.UseVisualStyleBackColor = true;
            btnRent.Click += button1_Click;
            // 
            // btnReview
            // 
            btnReview.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnReview.Location = new Point(632, 247);
            btnReview.Name = "btnReview";
            btnReview.Size = new Size(156, 76);
            btnReview.TabIndex = 2;
            btnReview.Text = "Review";
            btnReview.UseVisualStyleBackColor = true;
            btnReview.Click += btnReview_Click;
            // 
            // labReview
            // 
            labReview.AutoSize = true;
            labReview.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            labReview.Location = new Point(448, 195);
            labReview.Name = "labReview";
            labReview.Size = new Size(221, 28);
            labReview.TabIndex = 3;
            labReview.Text = "To Review Click Here :";
            // 
            // labRent
            // 
            labRent.AutoSize = true;
            labRent.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            labRent.Location = new Point(435, 37);
            labRent.Name = "labRent";
            labRent.Size = new Size(197, 28);
            labRent.TabIndex = 4;
            labRent.Text = "To Rent Click Here :";
            // 
            // btnToBack
            // 
            btnToBack.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnToBack.Location = new Point(632, 374);
            btnToBack.Name = "btnToBack";
            btnToBack.Size = new Size(156, 64);
            btnToBack.TabIndex = 5;
            btnToBack.Text = "<<Back";
            btnToBack.UseVisualStyleBackColor = true;
            btnToBack.Click += btnToBack_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnToBack);
            Controls.Add(labRent);
            Controls.Add(labReview);
            Controls.Add(btnReview);
            Controls.Add(btnRent);
            Controls.Add(dataGridView1);
            Name = "Form5";
            Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnRent;
        private Button btnReview;
        private Label labReview;
        private Label labRent;
        private Button btnToBack;
    }
}