﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class Form5 : Form
    {
        Form4 previousForm;
        public Form5(Form4 form4)
        {

            InitializeComponent();
            previousForm = form4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7(this);
            form7.Show();
        }

        private void btnReview_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6(this);
            form6.Show();
        }

        private void btnToBack_Click(object sender, EventArgs e)
        {
            previousForm.Show();  
            this.Close();
        }
    }
}
