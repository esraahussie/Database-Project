﻿namespace MovieRental
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labreviewenter = new Label();
            BoxReviewSubb = new TextBox();
            btnReviewSubb = new Button();
            btnToBack = new Button();
            SuspendLayout();
            // 
            // labreviewenter
            // 
            labreviewenter.AutoSize = true;
            labreviewenter.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            labreviewenter.Location = new Point(211, 22);
            labreviewenter.Name = "labreviewenter";
            labreviewenter.Size = new Size(381, 57);
            labreviewenter.TabIndex = 0;
            labreviewenter.Text = "Enter Your Review";
            // 
            // BoxReviewSubb
            // 
            BoxReviewSubb.Location = new Point(84, 91);
            BoxReviewSubb.Multiline = true;
            BoxReviewSubb.Name = "BoxReviewSubb";
            BoxReviewSubb.Size = new Size(643, 188);
            BoxReviewSubb.TabIndex = 1;
            BoxReviewSubb.TextChanged += BoxReviewSubb_TextChanged;
            // 
            // btnReviewSubb
            // 
            btnReviewSubb.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            btnReviewSubb.Location = new Point(122, 309);
            btnReviewSubb.Name = "btnReviewSubb";
            btnReviewSubb.Size = new Size(201, 74);
            btnReviewSubb.TabIndex = 2;
            btnReviewSubb.Text = "Submit";
            btnReviewSubb.UseVisualStyleBackColor = true;
            btnReviewSubb.Click += btnReviewSubb_Click;
            // 
            // btnToBack
            // 
            btnToBack.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            btnToBack.Location = new Point(521, 309);
            btnToBack.Name = "btnToBack";
            btnToBack.Size = new Size(206, 74);
            btnToBack.TabIndex = 3;
            btnToBack.Text = "<<Back";
            btnToBack.UseVisualStyleBackColor = true;
            btnToBack.Click += btnToBack_Click;
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnToBack);
            Controls.Add(btnReviewSubb);
            Controls.Add(BoxReviewSubb);
            Controls.Add(labreviewenter);
            Name = "Form6";
            Text = "Form6";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labreviewenter;
        private TextBox BoxReviewSubb;
        private Button btnReviewSubb;
        private Button btnToBack;
    }
}