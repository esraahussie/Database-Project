﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRental
{
    public partial class Form6 : Form
    {
        Form5 previousForm;

        public Form6(Form5 form5)
        {
            InitializeComponent();
            previousForm = form5;
        }
       
        private void BoxReviewSubb_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnReviewSubb_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Saved successfully. Thank you for your feedback.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BoxReviewSubb.Clear();
        }

        private void btnToBack_Click(object sender, EventArgs e)
        {
            previousForm.Show(); 
            this.Close();
        }
    }
}
