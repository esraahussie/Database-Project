﻿namespace MovieRental
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            labWayPay = new Label();
            comboxPay = new ComboBox();
            labUserName = new Label();
            labPass = new Label();
            BoxUserName = new TextBox();
            BoxPass = new TextBox();
            btnSubRentDetails = new Button();
            btnToBack = new Button();
            labPay = new Label();
            labDateTime = new Label();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            labFrom = new Label();
            labTo = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.ForeColor = Color.Blue;
            label1.Location = new Point(324, 9);
            label1.Name = "label1";
            label1.Size = new Size(151, 67);
            label1.TabIndex = 0;
            label1.Text = "Rent ";
            // 
            // labWayPay
            // 
            labWayPay.AutoSize = true;
            labWayPay.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labWayPay.Location = new Point(12, 159);
            labWayPay.Name = "labWayPay";
            labWayPay.Size = new Size(137, 25);
            labWayPay.TabIndex = 1;
            labWayPay.Text = "Payment With";
            // 
            // comboxPay
            // 
            comboxPay.FormattingEnabled = true;
            comboxPay.Location = new Point(161, 163);
            comboxPay.Name = "comboxPay";
            comboxPay.Size = new Size(258, 28);
            comboxPay.TabIndex = 2;
            comboxPay.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // labUserName
            // 
            labUserName.AutoSize = true;
            labUserName.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labUserName.Location = new Point(19, 277);
            labUserName.Name = "labUserName";
            labUserName.Size = new Size(104, 25);
            labUserName.TabIndex = 3;
            labUserName.Text = "UserName";
            // 
            // labPass
            // 
            labPass.AutoSize = true;
            labPass.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labPass.Location = new Point(26, 373);
            labPass.Name = "labPass";
            labPass.Size = new Size(97, 25);
            labPass.TabIndex = 4;
            labPass.Text = "Password";
            // 
            // BoxUserName
            // 
            BoxUserName.Location = new Point(161, 275);
            BoxUserName.Name = "BoxUserName";
            BoxUserName.Size = new Size(258, 27);
            BoxUserName.TabIndex = 5;
            BoxUserName.TextChanged += BoxUserName_TextChanged;
            // 
            // BoxPass
            // 
            BoxPass.Location = new Point(161, 374);
            BoxPass.Name = "BoxPass";
            BoxPass.Size = new Size(258, 27);
            BoxPass.TabIndex = 6;
            BoxPass.UseSystemPasswordChar = true;
            BoxPass.TextChanged += BoxPass_TextChanged;
            // 
            // btnSubRentDetails
            // 
            btnSubRentDetails.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnSubRentDetails.Location = new Point(574, 293);
            btnSubRentDetails.Name = "btnSubRentDetails";
            btnSubRentDetails.Size = new Size(167, 44);
            btnSubRentDetails.TabIndex = 7;
            btnSubRentDetails.Text = "Submit";
            btnSubRentDetails.UseVisualStyleBackColor = true;
            btnSubRentDetails.Click += btnSubRentDetails_Click;
            // 
            // btnToBack
            // 
            btnToBack.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnToBack.Location = new Point(574, 374);
            btnToBack.Name = "btnToBack";
            btnToBack.Size = new Size(167, 44);
            btnToBack.TabIndex = 8;
            btnToBack.Text = "<<Back";
            btnToBack.UseVisualStyleBackColor = true;
            btnToBack.Click += btnToBack_Click;
            // 
            // labPay
            // 
            labPay.AutoSize = true;
            labPay.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            labPay.Location = new Point(204, 104);
            labPay.Name = "labPay";
            labPay.Size = new Size(117, 35);
            labPay.TabIndex = 9;
            labPay.Text = "Payment";
            // 
            // labDateTime
            // 
            labDateTime.AutoSize = true;
            labDateTime.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            labDateTime.Location = new Point(492, 91);
            labDateTime.Name = "labDateTime";
            labDateTime.Size = new Size(235, 35);
            labDateTime.TabIndex = 10;
            labDateTime.Text = "Date_Time_Picker :";
            labDateTime.Click += label6_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(574, 159);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(167, 27);
            dateTimePicker1.TabIndex = 11;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(574, 226);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(167, 27);
            dateTimePicker2.TabIndex = 12;
            // 
            // labFrom
            // 
            labFrom.AutoSize = true;
            labFrom.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labFrom.Location = new Point(492, 159);
            labFrom.Name = "labFrom";
            labFrom.Size = new Size(59, 25);
            labFrom.TabIndex = 13;
            labFrom.Text = "From";
            // 
            // labTo
            // 
            labTo.AutoSize = true;
            labTo.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            labTo.Location = new Point(506, 228);
            labTo.Name = "labTo";
            labTo.Size = new Size(33, 25);
            labTo.TabIndex = 14;
            labTo.Text = "To";
            // 
            // Form7
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(labTo);
            Controls.Add(labFrom);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            Controls.Add(labDateTime);
            Controls.Add(labPay);
            Controls.Add(btnToBack);
            Controls.Add(btnSubRentDetails);
            Controls.Add(BoxPass);
            Controls.Add(BoxUserName);
            Controls.Add(labPass);
            Controls.Add(labUserName);
            Controls.Add(comboxPay);
            Controls.Add(labWayPay);
            Controls.Add(label1);
            Name = "Form7";
            Text = "Form7";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label labWayPay;
        private ComboBox comboxPay;
        private Label labUserName;
        private Label labPass;
        private TextBox BoxUserName;
        private TextBox BoxPass;
        private Button btnSubRentDetails;
        private Button btnToBack;
        private Label labPay;
        private Label labDateTime;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label labFrom;
        private Label labTo;
    }
}