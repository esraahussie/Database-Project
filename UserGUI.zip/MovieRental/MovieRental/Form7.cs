﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MovieRental
{
    public partial class Form7 : Form
    {
        Form5 previousForm;
        public Form7(Form5 form5)
        {
            InitializeComponent();
            comboxPay.Items.Add("Visa");
            comboxPay.Items.Add("MasterCard");
            comboxPay.Items.Add("Cash On Delivery");
            comboxPay.Items.Add("Wallet");
            previousForm = form5;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSubRentDetails_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rental completed successfully. Enjoy the movie!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            comboxPay.Text = "";
            BoxPass.Clear();
            BoxUserName.Clear();
            dateTimePicker1.Text = "";
            dateTimePicker2.Text = "";
        }

        private void BoxUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void BoxPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnToBack_Click(object sender, EventArgs e)
        {
            previousForm.Show(); 
            this.Close();
        }
    }
}
