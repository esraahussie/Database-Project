﻿namespace MovieRental
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labSearch = new Label();
            BoxSearch = new TextBox();
            btnSubbSearch = new Button();
            btnToBack = new Button();
            SuspendLayout();
            // 
            // labSearch
            // 
            labSearch.AutoSize = true;
            labSearch.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
            labSearch.Location = new Point(310, 38);
            labSearch.Name = "labSearch";
            labSearch.Size = new Size(157, 57);
            labSearch.TabIndex = 0;
            labSearch.Text = "Search";
            // 
            // BoxSearch
            // 
            BoxSearch.Location = new Point(167, 121);
            BoxSearch.Name = "BoxSearch";
            BoxSearch.Size = new Size(467, 27);
            BoxSearch.TabIndex = 1;
            BoxSearch.TextChanged += textBox1_TextChanged;
            // 
            // btnSubbSearch
            // 
            btnSubbSearch.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnSubbSearch.Location = new Point(573, 177);
            btnSubbSearch.Name = "btnSubbSearch";
            btnSubbSearch.Size = new Size(190, 48);
            btnSubbSearch.TabIndex = 2;
            btnSubbSearch.Text = "Submit....";
            btnSubbSearch.UseVisualStyleBackColor = true;
            btnSubbSearch.Click += btnSubbSearch_Click_1;
            // 
            // btnToBack
            // 
            btnToBack.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            btnToBack.Location = new Point(573, 337);
            btnToBack.Name = "btnToBack";
            btnToBack.Size = new Size(185, 44);
            btnToBack.TabIndex = 3;
            btnToBack.Text = "<<Back";
            btnToBack.UseVisualStyleBackColor = true;
            btnToBack.Click += btnToBack_Click;
            // 
            // Form8
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnToBack);
            Controls.Add(btnSubbSearch);
            Controls.Add(BoxSearch);
            Controls.Add(labSearch);
            Name = "Form8";
            Text = "Form8";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labSearch;
        private TextBox BoxSearch;
        private Button btnSubbSearch;
        private Button btnToBack;
    }
}