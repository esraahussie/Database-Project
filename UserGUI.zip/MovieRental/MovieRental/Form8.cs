﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MovieRental
{
    public partial class Form8 : Form
    {
        Form4 previousForm;
        public Form8(Form4 form4)
        {
            InitializeComponent();
            previousForm = form4;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSubbSearch_Click(object sender, EventArgs e)
        {

        }

        private void btnToBack_Click(object sender, EventArgs e)
        {
            previousForm.Show();
            this.Close();
        }

        private void btnSubbSearch_Click_1(object sender, EventArgs e)
        {

        }
    }
}
